<?php
// establish connection and login to mysql database
$host="http://swps-dev.cgasberg.dk/myadmin/";	
$username="cgasberg_swpsdev";
$password="congobajer2013";
$db_name="cgasberg_swps-dev-test";
$tbl_name="login";
?>