<?php 
$db_hostname = "localhost";
$db_database = "calendar";
$db_username = "root";
$db_password = "";
?>